function Y = Pej_Transform_logit(X)
Y = log(X./(1-X));
end