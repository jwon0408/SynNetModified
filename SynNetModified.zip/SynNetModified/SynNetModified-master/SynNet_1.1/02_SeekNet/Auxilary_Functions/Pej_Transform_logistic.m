function Y = Pej_Transform_logistic(X)
Y = 1./(1+exp(-X));
end