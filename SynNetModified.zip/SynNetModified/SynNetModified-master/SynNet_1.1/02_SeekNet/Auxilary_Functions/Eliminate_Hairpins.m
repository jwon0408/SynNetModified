function new_miRNA_Data = Eliminate_Hairpins(miRNA_Data, ver_num)

    my_miRBase_Data = Get_Human_miRNA(ver_num);

    new_miRNA_Data.SampleID = miRNA_Data.SampleID;
    new_miRNA_Data.SampleLabels = miRNA_Data.SampleLabels;
    new_miRNA_Data.Annotation = miRNA_Data.Annotation;
    
    [miRNA_num, Sample_num] = size(miRNA_Data.Dnormed);
    
    mature_count = 0;
    
    for i=1:length(miRNA_Data.GeneNames)
        match_not_found = 1; 
        
        if ismissing(miRNA_Data.Mature_Sequence(i))
            
            combined_miRNAs = strsplit(string(miRNA_Data.GeneNames(i)), '/');
            combined_num = length(combined_miRNAs);
        
            if combined_num > 1
               %disp(combined_miRNAs);
            
               first_pieces  = strsplit(combined_miRNAs(1), '-');
               first_length = length(first_pieces);
        
                for k = 2:combined_num
                    cur_pieces = strsplit(combined_miRNAs(k), '-');
                    cur_length = length(cur_pieces);
                
                    if first_length > cur_length
                        cur_head = strjoin(first_pieces(1:(first_length-cur_length)), "-");
                        cur_tail = strjoin(cur_pieces, "-");
                        combined_miRNAs(k) = strjoin([cur_head cur_tail], "-");
                    end
                end
            
                %disp(combined_miRNAs);
            end
            
            h=1;
            while (h<=combined_num) && match_not_found
                j=1;
                while (j<=length(my_miRBase_Data.hairpin))&& match_not_found 
                    if my_miRBase_Data.hairpin(j, 1) == combined_miRNAs(h)
                        match_not_found = 0;
                    end
                    j=j+1;
                end
                h=h+1;
            end
        end
        
        if match_not_found
            mature_count = mature_count + 1;
            new_miRNA_Data.GeneNames(mature_count,1) = string(miRNA_Data.GeneNames(i));
            new_miRNA_Data.Dnormed(mature_count, 1:Sample_num) = miRNA_Data.Dnormed(i, :);
            new_miRNA_Data.Mature_Sequence(mature_count,1) = string(miRNA_Data.Mature_Sequence(i));
        end
    end
end 
