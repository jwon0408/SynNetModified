function [miRNA_Data, not_found_indices] = Find_miRNA_Sequences(miRNA_Data, ver_num)

    my_miRBase_human = Get_Human_miRNA(ver_num);
    
    not_found_indices = [];
    miRNA_Data.Mature_Sequence = string(NaN(length(miRNA_Data.GeneNames),1));

    for i=1:length(miRNA_Data.GeneNames)
    
        match_not_found = 1;
        
        combined_miRNAs = strsplit(string(miRNA_Data.GeneNames(i)), '/');
        combined_num = length(combined_miRNAs);
        
        if combined_num > 1
            %disp(combined_miRNAs);
            
            first_pieces  = strsplit(combined_miRNAs(1), '-');
            first_length = length(first_pieces);
        
            for k = 2:combined_num
                cur_pieces = strsplit(combined_miRNAs(k), '-');
                cur_length = length(cur_pieces);
                
                if first_length > cur_length
                    
                    cur_head = strjoin(first_pieces(1:(first_length-cur_length)), "-");
                    cur_tail = strjoin(cur_pieces, "-");
                    
                    combined_miRNAs(k) = strjoin([cur_head cur_tail], "-");
                end
            end
            
            %disp(combined_miRNAs);
        end
        
        h=1;
        while (h<=combined_num) && match_not_found
            j=1;
            while (j<=length(my_miRBase_human.mature))&& match_not_found 
                if my_miRBase_human.mature(j, 1) == combined_miRNAs(h)
                    miRNA_Data.Mature_Sequence(i,1) = my_miRBase_human.mature(j, 2);
                    match_not_found = 0;
                end
                j=j+1;
            end
            h=h+1;
        end
    
        if match_not_found
            not_found_indices = [not_found_indices; i];
        end
    end

end