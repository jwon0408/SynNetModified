function [miRNA_Data, not_found_new] = Find_Sequences_Backup(miRNA_Data, not_found_indices, ver_num_backup)

    my_miRBase_backup = Get_Human_miRNA(ver_num_backup);
    not_found_new = [];
    
    for i=1:length(not_found_indices)
        matchNotFound = 1;
        
        combined_miRNAs = strsplit(string(miRNA_Data.GeneNames(not_found_indices(i))), '/');
        combined_num = length(combined_miRNAs);
        
        if combined_num > 1
            %disp(combined_miRNAs);
            
            first_pieces  = strsplit(combined_miRNAs(1), '-');
            first_length = length(first_pieces);
        
            for k = 2:combined_num
                cur_pieces = strsplit(combined_miRNAs(k), '-');
                cur_length = length(cur_pieces);
                
                if first_length > cur_length
                    
                    cur_head = strjoin(first_pieces(1:(first_length-cur_length)), "-");
                    cur_tail = strjoin(cur_pieces, "-");
                    
                    combined_miRNAs(k) = strjoin([cur_head cur_tail], "-");
                end
            end
            
            %disp(combined_miRNAs);
        end
        
        h=1;
        while (h<=combined_num) && matchNotFound
            j=1;
            while matchNotFound && (j<=length(my_miRBase_backup.mature))
                if my_miRBase_backup.mature(j,1) == combined_miRNAs(h)
                    miRNA_Data.Mature_Sequence(not_found_indices(i),1) = my_miRBase_backup.mature(j,2);
                    matchNotFound = 0;
                end 
                j=j+1;
            end
            h=h+1;
        end
        
        if matchNotFound
            not_found_new = [not_found_new; not_found_indices(i)];
        end
    end 
 
end 