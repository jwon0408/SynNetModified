function my_miRBase_human = Create_my_miRBase_guided(ver_num)
%Create a streamlined database of human miRNAs including two pieces
%of information: 1)ID and 2) Sequence
    
    if isempty(strfind(string(ver_num), '.'))
        ext_name = string(ver_num) + '.0.fa';
    else
        ext_name = string(ver_num) + '.fa';
    end
    
    DB_filepath1 = char("Mature_Sequences/mature_v"+ext_name);
    my_miRBase_raw = fastaread(DB_filepath1); 
    human_count = 0;
    for i=1:length(my_miRBase_raw)
        curHeader = strsplit(my_miRBase_raw(i).Header, ' ');
        curID = strsplit(string(curHeader(1)), '-');
        if curID(1) == 'hsa'
            human_count = human_count+1;
            my_miRBase_human(human_count, 1) = lower(string(curHeader(1)));
            my_miRBase_human(human_count, 2) = string(my_miRBase_raw(i).Sequence);
        end
    end

    if (ver_num >= 10) && (ver_num < 15) 
        DB_filepath2 = char("Mature_Sequences/maturestar_v" + ext_name);
        my_miRBase_raw_2 = fastaread(DB_filepath2);

        for i=1:length(my_miRBase_raw_2)
            curHeader = strsplit(my_miRBase_raw_2(i).Header, ' ');
            curID = strsplit(string(curHeader(1)), '-');
            
            if curID(1) == 'hsa'
                human_count = human_count+1;
                my_miRBase_human(human_count, 1) = lower(string(curHeader(1)));
                my_miRBase_human(human_count, 2) = string(my_miRBase_raw_2(i).Sequence);
            end
        end 
    end 
end 