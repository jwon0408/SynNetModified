function Combined_miRNA_Data = Combine_multiple_miRNA_Data(filenames_file)

file_path = "Example_Data/" + string(filenames_file) + ".txt";
files = importdata(file_path); 
file_num = length(files.textdata);

if file_num > length(files.data)
    error('miRBase version is not provided for all datasets. For datasets with unknown miRBase version, set it to the latest version (i.e. 21).')
end

next_file = 1;
Combined_miRNA_Data = Complete_Finding_Sequences(Read_miRNA_Datafile(files.textdata(next_file)), files.data(next_file)); 
    
while next_file < file_num
      next_file = next_file + 1;
      miRNA_Data_Next = Complete_Finding_Sequences(Read_miRNA_Datafile(files.textdata(next_file)), files.data(next_file));
      Combined_miRNA_Data = Combine_miRNA_Data(Combined_miRNA_Data, miRNA_Data_Next);
end
 
end