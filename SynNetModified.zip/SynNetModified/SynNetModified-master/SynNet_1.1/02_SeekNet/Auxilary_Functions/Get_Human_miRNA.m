function my_human_miRBase = Get_Human_miRNA(ver_num)
    
    if isempty(strfind(string(ver_num), '.'))
        filepath = char("Auxilary_Functions/Human_miRNA/v"+ string(ver_num) + ".0_Human_miRNA.mat");
    else
        filepath = char("Auxilary_Functions/Human_miRNA/v"+ string(ver_num) + "_Human_miRNA.mat");
    end
    
    load(filepath);
    if Human_miRNA.ver == ver_num
        my_human_miRBase = Human_miRNA;
    else 
        disp("Wrong Human_miRNA version loaded! Loaded version: "+Human_miRNA.ver);
    end
    
    clear Human_miRNA;
end