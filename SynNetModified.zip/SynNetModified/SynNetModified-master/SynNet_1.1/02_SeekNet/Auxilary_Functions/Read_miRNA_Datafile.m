function miRNA_Data = Read_miRNA_Datafile(filename)
%Read a single raw dataset and normalize.

file_path = "Example_Data/" + string(filename) + ".txt";
RawData = importdata(file_path);

[text_r, text_c] = size(RawData.textdata);
[num_r, num_c] = size(RawData.data);

miRNA_Data.GeneNames = strtrim(lower(RawData.textdata(3:text_r, 1)));
miRNA_Data.Expressions = RawData.data(2:num_r, 1:num_c);

SampleID = string(RawData.textdata(1, 2:text_c));

if length(unique(SampleID)) < length(SampleID)
        error('The SampleIDs provided in in %s are not unique!', filename)
end

miRNA_Data.SampleID = SampleID;

miRNA_Data.SampleLabels = SampleID;

Annotation = RawData.data(1, :);

if any(isnan(Annotation))
       error('The "Annotation" row in %s should only contain numeric values!', filename)
end

miRNA_Data.Annotation = Annotation;

miRNA_Data = normalize_miRNAs(miRNA_Data);
miRNA_Data.Dnormed = miRNA_Data.Dnormed + miRNA_Data.Pseudocount;

end
