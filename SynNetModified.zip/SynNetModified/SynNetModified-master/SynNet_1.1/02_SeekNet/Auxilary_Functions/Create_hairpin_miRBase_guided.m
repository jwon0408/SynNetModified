function my_miRBase_hairpin = Create_hairpin_miRBase_guided(ver_num)
    
    if isempty(strfind(string(ver_num), '.'))
        ext_name = string(ver_num) + '.0.fa';
    else
        ext_name = string(ver_num) + '.fa';
    end
    
    filepath = char('Hairpin_Sequences/hairpin_v'+ext_name);
    my_miRBase_raw = fastaread(filepath, 'TrimHeaders', true); 
    human_count = 0;
    for i=1:length(my_miRBase_raw)
        curID = strsplit(string(my_miRBase_raw(i).Header), '-');
        if curID(1) == 'hsa'
            human_count = human_count+1;
            my_miRBase_hairpin(human_count, 1) = lower(string(my_miRBase_raw(i).Header));
            my_miRBase_hairpin(human_count, 2) = string(my_miRBase_raw(i).Sequence);
        end
    end

end 