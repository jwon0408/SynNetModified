function Combined_miRNA_Data = Combine_miRNA_Data(miRNA_Data1, miRNA_Data2)

[exp_len1, sample_num1] = size(miRNA_Data1.Dnormed);
[exp_len2, sample_num2] = size(miRNA_Data2.Dnormed);

if exp_len1 > exp_len2
    Base_Data = miRNA_Data1;
    Base_len = exp_len1;
    Base_num = sample_num1;
    New_Data = miRNA_Data2;
    New_len = exp_len2;
    New_num = sample_num2;
    
elseif exp_len1 < exp_len2
    Base_Data = miRNA_Data2;
    Base_len = exp_len2;
    Base_num = sample_num2;
    New_Data = miRNA_Data1;
    New_len = exp_len1;
    New_num = sample_num1;
    
end

Combined_miRNA_Data.GeneNames = Base_Data.GeneNames; 
Combined_miRNA_Data.SampleID(1, 1:Base_num) = Base_Data.SampleID;
Combined_miRNA_Data.SampleLabels(1, 1:Base_num) = Base_Data.SampleLabels;
Combined_miRNA_Data.Annotation(1, 1:Base_num) = Base_Data.Annotation;

Combined_miRNA_Data.SampleID = [Combined_miRNA_Data.SampleID New_Data.SampleID];
Combined_miRNA_Data.SampleLabels = [Combined_miRNA_Data.SampleLabels New_Data.SampleLabels];
Combined_miRNA_Data.Annotation = [Combined_miRNA_Data.Annotation New_Data.Annotation];
Combined_miRNA_Data.Dnormed = Base_Data.Dnormed;
Combined_miRNA_Data.Mature_Sequence = Base_Data.Mature_Sequence;

not_found_indices = [];

for i=1:New_len
    matchNotFound = 1;
    
    j=1;
    while matchNotFound && (j<=Base_len)
           
        if ismissing(Base_Data.Mature_Sequence(j))|| ismissing(New_Data.Mature_Sequence(i))
            %skip missing values
            
        elseif Base_Data.Mature_Sequence(j) == New_Data.Mature_Sequence(i)
           Combined_miRNA_Data.Dnormed(j, Base_num+1:Base_num+New_num) = New_Data.Dnormed(i,:);
           matchNotFound = 0;
           
        end
        j=j+1;
    end
    
    if matchNotFound
        not_found_indices = [not_found_indices; i];
    end
end

Combined_miRNA_Data.GeneNames = [Combined_miRNA_Data.GeneNames; New_Data.GeneNames(not_found_indices)];
Combined_miRNA_Data.Dnormed = [Combined_miRNA_Data.Dnormed; [zeros(length(not_found_indices), Base_num) New_Data.Dnormed(not_found_indices,:)]];
Combined_miRNA_Data.Mature_Sequence = [Combined_miRNA_Data.Mature_Sequence; New_Data.Mature_Sequence(not_found_indices)];

end