function miRNA_Data = Complete_Finding_Sequences(miRNA_Data, ver_num)

    search_depth = 5;
    
    versions = [9.0; 9.1; 9.2; 10.0; 10.1; 
                11.0; 12.0; 13.0; 14.0; 
                15.0; 16.0; 17.0; 18.0; 19.0; 20.0; 21.0];
   
    if isnan(ver_num)
        ver_index = length(versions);
        ver_num = versions(ver_index);
        
    else
        matchNotFound = 1;
        i=1;

        while matchNotFound && (i<=length(versions))
            if versions(i) == ver_num
                ver_index = i;
                matchNotFound = 0;
            end
            i=i+1;
        end
 
    end
    
    [miRNA_Data, not_found_indices] = Find_miRNA_Sequences(miRNA_Data, ver_num);

    cur_ver_index = ver_index;
    proceed_flag = double(length(not_found_indices) > 0);
    
    while (proceed_flag > 0) && (proceed_flag < search_depth) && (cur_ver_index < length(versions))
          %disp(versions(cur_ver_index));
          prev_notFoundCount = length(not_found_indices);
          %disp(prev_notFoundCount);
          cur_ver_index = cur_ver_index + 1;
          [miRNA_Data, not_found_indices] = Find_Sequences_Backup(miRNA_Data, not_found_indices, versions(cur_ver_index));
          cur_notFoundCount = length(not_found_indices);
          proceed_flag = proceed_flag + double(prev_notFoundCount > cur_notFoundCount); 
    end
    
    cur_ver_index = ver_index;
    proceed_flag = double(length(not_found_indices) > 0);
    
    while (proceed_flag > 0) && (proceed_flag < search_depth) && (cur_ver_index > 1)
          %disp(versions(cur_ver_index));
          prev_notFoundCount = length(not_found_indices);
          %disp(prev_notFoundCount);
          cur_ver_index = cur_ver_index - 1;
          [miRNA_Data, not_found_indices] = Find_Sequences_Backup(miRNA_Data, not_found_indices, versions(cur_ver_index));
          cur_notFoundCount = length(not_found_indices);
          proceed_flag = proceed_flag + double(prev_notFoundCount > cur_notFoundCount); 
    end
    
    %disp("Starting hairpin elimination");
    
    cur_ver_index = ver_index;
    proceed_flag = double(length(not_found_indices) > 0);
    
    while (proceed_flag > 0) && (proceed_flag < search_depth) && (cur_ver_index < length(versions))
          %disp(versions(cur_ver_index));
          prev_miRNA_count = length(miRNA_Data.GeneNames);
          %disp(prev_miRNA_count);
          cur_ver_index = cur_ver_index + 1;
          miRNA_Data = Eliminate_Hairpins(miRNA_Data, versions(cur_ver_index));
          cur_miRNA_count = length(miRNA_Data.GeneNames);
          proceed_flag = proceed_flag + double(prev_miRNA_count > cur_miRNA_count); 
    end
    
    cur_ver_index = ver_index;
    proceed_flag = 1;
    
    while (proceed_flag > 0) && (proceed_flag < search_depth) && (cur_ver_index > 1)
          %disp(versions(cur_ver_index));
          prev_miRNA_count = length(miRNA_Data.GeneNames);
          %disp(prev_miRNA_count);
          cur_ver_index = cur_ver_index - 1;
          miRNA_Data = Eliminate_Hairpins(miRNA_Data, versions(cur_ver_index));
          cur_miRNA_count = length(miRNA_Data.GeneNames);
          proceed_flag = proceed_flag + double(prev_miRNA_count > cur_miRNA_count); 
    end
end